﻿$(document).ready( function(){
    $(".my-foto").imagezoomsl({

        zoomrange: [2, 2]
    });

});